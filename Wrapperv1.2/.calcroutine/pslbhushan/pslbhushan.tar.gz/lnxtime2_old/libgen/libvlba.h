
 
void aberrat (double *,double *,double *,double *);
double arccos(double *);  
double arcsin(double *);  
void cvrtuc(char *s);
int date2mjd(char *);
char *mjd2date(int , char *);
void dir_cos (double *,double *,double *);
double dotpr3 (double *,double *);
double fangle_(char *,int *);
long sangle_(double *,char *,char *);
double frac(double *);
float gastm(int);
double obliq(double *);
void nutate(double *,double *,double *); 
int ltostr(int,char *,int,int);
void nutrotn(double *,double *,double *,double *,double *);
double position(double *,double *,double *,double *);
void prcesj2(double *,double *,double *);
double rduce2p(double *);
void rectpol(double *,double *,double *);
long stime_(double *,char *,char *);
void rotate(double *,double *,double *);
void rformat_(double *,char *);
void sformat_(double *,char *);
int srclist(char *,char *,int);






