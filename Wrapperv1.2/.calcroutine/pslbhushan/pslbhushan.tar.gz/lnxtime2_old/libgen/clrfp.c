/*#include <f77/f77_floatingpoint.h>*/

void clearfp_()
{
  char out[16];
  char *pt;
  int i;
  pt=out;
/*  i=ieee_flags_("clear","exception","all",&pt);*/
}
