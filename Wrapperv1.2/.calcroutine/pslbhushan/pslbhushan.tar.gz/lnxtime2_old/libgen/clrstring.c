/* clrstring
This routine clears a string of length b
*/

void clrstring(a,b)
char *a;
int b;
{
int i;
for (i=0; i < b-2;i++)
*(a+i)=' ';
*(a+b-1)='\0';
}
