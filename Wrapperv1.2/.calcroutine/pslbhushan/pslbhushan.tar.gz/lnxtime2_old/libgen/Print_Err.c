
/*xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*/
/* Print_Err
prints debug info on screen 
*/
#include <stdio.h>

void	Print_Err(dstr)
unsigned char	*dstr;
{
fprintf(stderr,"Print_Err:,%s\n",dstr);	
}
