# LaTeX2HTML 95.1 (Fri Jan 20 1995)
# Associate image original text (scrambled) with physical files.

$key = q/{_inline}$*${_inline}/;
$cached_env_img{$key} ='<IMG  ALIGN=BOTTOM ALT="" SRC="img1.gif">'; 

1;

