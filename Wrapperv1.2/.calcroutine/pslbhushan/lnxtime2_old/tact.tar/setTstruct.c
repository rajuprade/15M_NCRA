#include <tact.h>

static char rcsid[]="$Id: setTstruct.c,v 1.2 2002/10/31 10:07:54 chengalu Exp $";

#define SET_ANG(s1,v,s2,x)     {if(!strcmp(s1,s2)){\
                                  if(s2a(v,&x)){\
				   tact_err(__FILE__,"Illegal to set %s",s1,NULL);\
                                   tact_err(NULL," to %s\n",v,NULL);\
                                   return 1;}\
                                  m=1;continue;}}

#define SET_REAL(s1,v,s2,x)     {if(!strcmp(s1,s2)){\
                                  x=atof(v);\
                                  m=1;continue;}}

#define SET_CHAR(s1,v,s2,x)    {if(!strcmp(s1,s2)){\
                                  x=v[0];\
                                  m=1;continue;}}
#define SET_INT(s1,v,s2,x)    {if(!strcmp(s1,s2)){\
                                  x=(int)atoi(v);\
                                  m=1;continue;}}

int setTstruct(Gcord *gc, Garg *ga)
{
  int   na,nm;
  char  *aw[MAX_ARG],am[MAX_CMD_LEN];
  char  *ca;

  char  i,m;

  ca=ga->ca;
  /* decompose the command argument */
  if((na=prarg(ca, aw))==-1){
    tact_err(__FILE__,"Bad Arg %s\n",ca,NULL);
    return 1;
  }
  /* must have even number of arguments */
  if(na %2 ){
    tact_err(__FILE__,"Odd number (%i) of Argumenets Illegal \n",na,NULL);
    tact_err(__FILE__,"[%s]\n",ga->ca,NULL);
    return 1;
  }

  for(m=0,i=0;i<na;i+=2){

    /* angles and time */
    SET_ANG(aw[i],aw[i+1],"ra",gc->ra); 
    SET_ANG(aw[i],aw[i+1],"ra1",gc->ra1);
    SET_ANG(aw[i],aw[i+1],"dec",gc->dec);
    SET_ANG(aw[i],aw[i+1],"dec1",gc->dec1);
    SET_ANG(aw[i],aw[i+1],"dra",gc->dra);
    SET_ANG(aw[i],aw[i+1],"ddec",gc->ddec);
    SET_ANG(aw[i],aw[i+1],"dra1",gc->dra1);
    SET_ANG(aw[i],aw[i+1],"ddec1",gc->ddec1);
    SET_ANG(aw[i],aw[i+1],"px",gc->px);
    SET_ANG(aw[i],aw[i+1],"lct",gc->lct);
    SET_ANG(aw[i],aw[i+1],"utc",gc->utc);
    SET_ANG(aw[i],aw[i+1],"dut",gc->dut);
    SET_ANG(aw[i],aw[i+1],"lst",gc->lst);
    SET_ANG(aw[i],aw[i+1],"ut1",gc->ut1);
    SET_ANG(aw[i],aw[i+1],"gmst",gc->gmst);
    SET_ANG(aw[i],aw[i+1],"gast",gc->gast);
    SET_ANG(aw[i],aw[i+1],"tzone",gc->tzone);
    SET_ANG(aw[i],aw[i+1],"glong",gc->glong);
    SET_ANG(aw[i],aw[i+1],"glat",gc->glat);
    SET_ANG(aw[i],aw[i+1],"elong",gc->elong);
    SET_ANG(aw[i],aw[i+1],"elat",gc->elat);
    SET_ANG(aw[i],aw[i+1],"alt",gc->alt);
    SET_ANG(aw[i],aw[i+1],"az",gc->az);
    SET_ANG(aw[i],aw[i+1],"ha",gc->ha);
    SET_ANG(aw[i],aw[i+1],"pa",gc->pa);
    SET_ANG(aw[i],aw[i+1],"tlat",gc->tlat);
    SET_ANG(aw[i],aw[i+1],"tlong",gc->tlong);
    SET_ANG(aw[i],aw[i+1],"sglat",gc->sglat);
    SET_ANG(aw[i],aw[i+1],"sglong",gc->sglong);
    SET_ANG(aw[i],aw[i+1],"rise",gc->rise);
    SET_ANG(aw[i],aw[i+1],"set",gc->set);
    SET_ANG(aw[i],aw[i+1],"el_lim",gc->el_lim);

    /* doubles */
    SET_REAL(aw[i],aw[i+1],"epoch",gc->epoch);
    SET_REAL(aw[i],aw[i+1],"equinox",gc->equinox);
    SET_REAL(aw[i],aw[i+1],"epoch1",gc->epoch1);
    SET_REAL(aw[i],aw[i+1],"equinox1",gc->equinox1);
    SET_REAL(aw[i],aw[i+1],"rv",gc->rv);
    SET_REAL(aw[i],aw[i+1],"rv1",gc->rv1);
    SET_REAL(aw[i],aw[i+1],"mjd",gc->mjd);
    SET_REAL(aw[i],aw[i+1],"gyear",gc->gyear);
    SET_REAL(aw[i],aw[i+1],"gmonth",gc->gmonth);
    SET_REAL(aw[i],aw[i+1],"gday",gc->gday);
    SET_REAL(aw[i],aw[i+1],"height",gc->height);
    SET_REAL(aw[i],aw[i+1],"freq",gc->freq);
    SET_REAL(aw[i],aw[i+1],"freq1",gc->freq1);

    /*int */
    SET_INT(aw[i],aw[i+1],"velsys",gc->velsys);
    SET_INT(aw[i],aw[i+1],"vel1sys",gc->vel1sys);
    SET_INT(aw[i],aw[i+1],"veldef",gc->veldef);
    SET_INT(aw[i],aw[i+1],"freqsys",gc->velsys);
    SET_INT(aw[i],aw[i+1],"freq1sys",gc->vel1sys);

    /* char */
    SET_CHAR(aw[i],aw[i+1],"eprefix",gc->eprefix); 
    SET_CHAR(aw[i],aw[i+1],"e1prefix",gc->e1prefix); 

  
    tact_err(__FILE__,"No such structure member %s\n",aw[i],NULL);
    return 1;
  }
  
  /* free */
  for(i=0;i<na;i++)
    free(aw[i]);
  
  /* all done */
  return 0;
}
