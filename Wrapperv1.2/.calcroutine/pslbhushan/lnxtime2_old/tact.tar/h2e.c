#include <tact.h>

static char rcsid[]="$Id: h2e.c,v 1.1 1998/01/16 07:12:04 chengalu Exp $";

int h2e(Gcord *gc, Garg *ga)
/*
  converts from (alt,az) to (ha,dec) to (ra,dec)
  No correction for refraction effects or for abberation.

  input:
  alt
  az
  tlat
  lst

  output:
  ha
  dec1
  ra1

*/
{
  float ha,dec,tlat,az,alt;

  ha=gc->ha;
  dec=gc->dec1;
  tlat=gc->tlat;
  az=gc->az;
  alt=gc->alt;
  
  sla_h2e_(&az,&alt,&tlat,&ha,&dec);
  
  gc->ha=ha;
  gc->dec1=dec;
  gc->ra1=gc->lst-gc->ha;

  return 0;
}
