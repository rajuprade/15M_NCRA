#include <tact.h>
#include <ctype.h>

static char rcsid[]="$Id: initTbuf.c,v 1.3 1998/02/08 11:49:31 chengalu Exp $";

int initTbuf(char *cb, char *cfl)
{
  FILE  *fp;
  char  fl[256],*cp;
  int prtactrc(FILE *fp, char *cb);

  /* clear the command buffer */
  cb[0]='\0';

  /* open the system default file */
  if((fp=fopen(TACT_SYS_DEF_FILE,"r"))!=NULL){
    if(prtactrc(fp,cb)){
      tact_err(__FILE__,"Error parsing init file %s",TACT_SYS_DEF_FILE,NULL);
      return 1;
    }
    fclose(fp);
  }

  /* open the users default file */
  if((cp=getenv("HOME")) !=NULL){
    strcpy(fl,cp);
    strcat(fl,"/.tactrc");
    if((fp=fopen(fl,"r"))!=NULL){
      if(prtactrc(fp,cb)){
	tact_err(__FILE__,"Error parsing init file %s",fl,NULL);
	return 1;
      } 
      fclose(fp);
    }
  }
  if((cp=getenv("PWD")) !=NULL){
    strcpy(fl,cp);
    strcat(fl,"/.tactrc");
    if((fp=fopen(fl,"r"))!=NULL){
      if(prtactrc(fp,cb)){
	tact_err(__FILE__,"Error parsing init file %s",fl,NULL);
	return 1;
      } 
      fclose(fp);
    }
  }
  if((cp=getenv("TACT_USR_DEF")) !=NULL){
    if((fp=fopen(cp,"r"))!=NULL){
      if(prtactrc(fp,cb)){
	tact_err(__FILE__,"Error parsing init file %s",fl,NULL);
	return 1;
      } 
      fclose(fp);
    }
  }
  /* open any command line specified file */
  if((fp=fopen(cfl,"r"))!=NULL){
    if(prtactrc(fp,cb)){
      tact_err(__FILE__,"Error parsing init file %s",cfl,NULL);
      return 1;
    } 
    fclose(fp);
  }
  
  /* all done */
  return 0;
}

#define STR_CAT(x,y,k)  {if((int)(strlen(x) + strlen(y)) < k)\
                          strcat(x,y);\
			 else{\
			  tact_err(__FILE__,"Command buffer Overflow\n",NULL);\
                          return 1;\
			 }}
int prtactrc(FILE *fp, char *cb)
{
  int i;
  char line[MAX_CMD_LEN];
  
  for(;fgets(line,MAX_BUFF_LEN,fp) !=NULL;){
    if(!(i=strlen(line)))
      continue;
    /* strip off trailing newline */
    if(line[i-1] == '\n')
      line[i]='\0';
    /* ignore comment lines */
    for(i=0;isspace(line[i]);i++);
    if(line[i] == '#'){
      continue;
    }
    /* replace newline in input file with space */
    STR_CAT(cb," ",MAX_BUFF_LEN);
    /* copy in the new line */
    STR_CAT(cb,line,MAX_BUFF_LEN);
  }

  /* all done */
  return 0;
}

#undef STR_CAT
