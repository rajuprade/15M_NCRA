#include <tact.h>

static char rcsid[]="$Id: ha2lst.c,v 1.1 1998/01/16 07:12:36 chengalu Exp $";

int ha2lst(Gcord *gc, Garg *ga)
/*
  converts from (ha,ra) to lst

  input:
  ha
  ra (assumed apparent ra)

  output:
  lst
*/

{

  gc->lst=gc->ha+gc->ra;

  return 0;
}
