#include <tact.h>

static char rcsid[]="$Id: resetep.c,v 1.1 2001/08/02 11:51:22 chengalu Exp $";

int resetep(Gcord *gc, Garg *ga)
{
/*
  copies co-ordiante set 1 into co-ordianate set 0

*/

     gc->epoch = gc->epoch1;
     gc->eprefix = gc->e1prefix;
     gc->equinox = gc->equinox1;
     
     return 0;
 
}


