#include <tact.h>

static char rcsid[]="$Id: tact.c,v 1.4 1998/02/08 11:25:49 chengalu Exp $";

FILE *tefp;     /* error file pointer */
int main(int argc, char **argv)
{
  Gcord gc;
  Garg  ga;

  struct TactCmd tcs[MAX_TACT_CMD];
  
  char   cb[MAX_BUFF_LEN];

  struct TactMacro tms[MAX_TACT_MACRO];

  long   bp=0;

  char  sr[ANG_STR_LEN],sd[ANG_STR_LEN];
  char cfl[256]="";

  int   i,j;
  int  c;

  extern char *optarg;

  /* clear the command buffer */
  for(i=0;i<MAX_BUFF_LEN;i++)
    cb[i]='\0';

  /* set the file pointers */
  ga.ofp=stdout;
  ga.hfp=stdout;
  ga.efp=stderr;
  tefp  =ga.efp;

  if(initTbuf(cb,cfl)){
    tact_err(__FILE__,"Error initializing command buffer\n",NULL);
    exit(1);
  }

  if(prcmdline(argc,argv, cb, &ga, &gc)){
    tact_err(__FILE__,"Error parsing command line\n",NULL);
    exit(1);
  }

  ga.tm= tms;
  ga.tc= tcs;
  ga.nm=0;
  ga.nc=0;

  if((ga.nc=setTcmd(tcs)) <= 0){
    tact_err(__FILE__,"setup error\n",NULL);
    exit(0);
  }

  if(excTcmd(cb,&bp,&ga,&gc,tcs,&ga.nc,tms,&ga.nm)){
    tact_err(__FILE__,"Error executing commands from buffer\n",NULL);
    exit(1);
  }
}
