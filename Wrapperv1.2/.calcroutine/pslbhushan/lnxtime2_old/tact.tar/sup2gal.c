#include <tact.h>

static char rcsid[]="$Id: sup2gal.c,v 1.1 1998/01/16 07:19:12 chengalu Exp $";

int sup2gal(Gcord *gc, Garg *ga)
/*
  converts from super galactic to galactic co-ordinates

  input:
  sglong
  glat
  
  output:
  glong
  glat
*/

{

  sla_supgal_(&gc->glong,&gc->glat,&gc->sglong,&gc->sglat);
  
  return 0;
}
