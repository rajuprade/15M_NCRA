/*
   function to break a string into tokens. The token separator is ARG_SEP.
   returns the number of tokens found and -1 on error. ARG_SEP can be
   escaped with an ESC_CHAR

*/
        
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <tact.h>

static char rcsid[]="$Id: prarg.c,v 1.2 1998/01/16 07:16:23 chengalu Exp $";

#define ARG_SEP ','
#define ESC_CHAR     '\\'

int prarg(char *ca, char *aw[])
{
    char p[MAX_CMD_LEN];
    int  na,i,j;


    for(na=0,i=0,j=0;;i++){
	/* clear the temporary buffer */
	if(j==0)
	    strcpy(p,"");

	if(ca[i]==ESC_CHAR)
	    if(ca[i+1] == ARG_SEP){
		/* copy the separator, ignore ESC_CHAR */
		p[j++]=ca[++i];
		continue;
	    }

	/* end of this argument word */
	if(ca[i] == ARG_SEP || ca[i] == '\0'){
	    /* Null comand argument string results in 0 arg words */
	    if(i){
		p[j]='\0';
		if(na < MAX_ARG){
		    if((aw[na]=malloc(j+1)) == NULL){
			tact_err(__FILE__,"Malloc Failure\n",NULL);
			return -1;
		    }
		    strcpy(aw[na++],p);
		}else{
		    tact_err(__FILE__,"MAX_ARG Exceeded\n",NULL);
		    return -1;
		}
	    }
	    /* end of command argument string */
	    if(ca[i] == '\0')
		return na;
	    else{
		j=0;
		continue;
	    }
	}
	
	/* copy the character into temporary buffer */
	p[j++]=ca[i];
    }

    /* should never get here */
    return -1;
}
#undef ARG_SEP
#undef ESC_CHAR
    
