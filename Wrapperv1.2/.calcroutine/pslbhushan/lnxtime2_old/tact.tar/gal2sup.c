#include <tact.h>

static char rcsid[]="$Id: gal2sup.c,v 1.1 1998/01/16 07:09:33 chengalu Exp $";

int gal2sup(Gcord *gc, Garg *ga)
/*
  converts from galactic to super galactic co-ordinates

  input:
  glong
  glat
  
  output:
  sglong
  sglat
*/

{

  sla_galsup_(&gc->glong,&gc->glat,&gc->sglong,&gc->sglat);
  
  return 0;
}
