#include <tact.h>

static char rcsid[]="";

int solcol(Gcord *gc, Garg *ga)
/*
  compute solar co-ordinates on a given day
  Input : mjd
  Output: ra,dec

*/

{ double d,g,q,l,e,ra,dec;

  d = gc->mjd +  2400000.5 - 2451545.0;
  g = DEG2RAD(357.529 + 0.98560028*d);
  q = 280.459 + 0.98564736*d; /* degrees */
  l = DEG2RAD(q + 1.915*sin(g) + 0.020*sin(2*g));
  e = DEG2RAD(23.439 - 0.00000036*d); 

  ra  = atan2(cos(e)*sin(l),cos(l));
  dec = asin(sin(e)*sin(l));
  
  gc->ra=ra;
  gc->dec=dec;

  return 0;
}
