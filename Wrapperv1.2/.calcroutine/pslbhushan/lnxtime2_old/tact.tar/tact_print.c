#include <tact.h>

static char rcsid[]="$Id: tact_print.c,v 1.5 2002/10/31 10:06:34 chengalu Exp $";

#define CHK_NEWLINE(s1)    {if(!strcmp(s1,"@NL")){\
                              m=1;\
                              pt=PTP_NL;}}

#define CHK_SPACE(s1)      {if(!strcmp(s1,"@SP")){\
                              m=1;\
                              pt=PTP_SP;}}

#define CHK_TAB(s1)        {if(!strcmp(s1,"@TB")){\
                              m=1;\
                              pt=PTP_TB;}}

#define CHK_HELP(s1)        {if(!strcmp(s1,"help")){\
                              m=1;\
                              pt=PTP_HELP;}}

#define CHK_ANG(s1,l,s2,s3,x) {if(!strcmp(s1,s2)){\
                              pD=x;\
                              pt=PTP_ANG;\
                              m=1;\
			      pst=ATP_DD;\
			      if(l){\
			      CHK_ANG_TYP(s3);}}}

#define CHK_TIME(s1,l,s2,s3,x) {if(!strcmp(s1,s2)){\
                              pD=x;\
                              pt=PTP_TIME;\
                              m=1;\
			      pst=ATP_HMS;\
			      if(l){\
			      CHK_ANG_TYP(s3);}}}

#define CHK_REAL(s1,l,s2,s3,x) {if(!strcmp(s1,s2)){\
                              pD=x;\
                              pt=PTP_REAL;\
                              m=1;\
                              if(l){\
			        strcpy(fmt,"%");\
			        strcat(fmt,am);\
                              }else{\
                                strcpy(fmt,"%f");}}}

#define CHK_INT(s1,l,s2,s3,x) {if(!strcmp(s1,s2)){\
                              pI=(int)floor(x);\
                              pt=PTP_INT;\
                              m=1;\
                              if(l){\
                                strcpy(fmt,"%");\
                                strcat(fmt,am);\
                              }else{\
                                strcpy(fmt,"%i");}}}

#define CHK_CHAR(s1,l,s2,s3,x) {if(!strcmp(s1,s2)){\
                              pC=x;\
                              pt=PTP_CHAR;\
                              m=1;\
                              if(l){\
                                strcpy(fmt,"%");\
                                strcat(fmt,am);\
                              }else{\
                                strcpy(fmt,"%c");}}}


#define CHK_ANG_TYP(s)   {if(!strcmp(s,"hms"))pst=ATP_HMS;\
                          if(!strcmp(s,"dms"))pst=ATP_DMS;\
                          if(!strcmp(s,"dh"))pst=ATP_DH;\
                          if(!strcmp(s,"dd"))pst=ATP_DD;\
                          if(!strcmp(s,"dr"))pst=ATP_DR;\
			  if(!strcmp(s,"dlo"))pst=ATP_DLO;}
					   
#define NO_MATCH(a)      {\
                         tact_err(__FILE__,"Illegal print request %s",a,NULL);\
                         return 1;}                         

int tact_print(Gcord *gc, Garg *ga)
{
  int   na,nm;
  char  *aw[MAX_ARG],am[MAX_CMD_LEN];
  
  int    pt,pst;

  int    i,j,m;
  int    k,l;

  double pD;
  int    pI;
  char   pC;

  char   sa[ANG_STR_LEN];
  char   *s;
  char   *ca;
  FILE   *fp;
  char   fmt[MAX_CMD_LEN];


  fp=ga->ofp;
  ca=ga->ca;

  /* decompose the command argument */
  if((na=prarg(ca, aw))==-1){
    tact_err(__FILE__,"Bad Arg %s\n",ca,NULL);
    return 1;
  }

  for(pt=-1,pst=-1,m=0,i=0;i<na;i++,m=0,pt=-1,pst=-1){
    if((nm=getargm(aw[i],am))==-1){
      tact_err(__FILE__,"Bad Arg Modifier %s",ca,NULL);
      return 1;
    }

    if(!m){CHK_HELP(aw[i])};
    if(!m){CHK_NEWLINE(aw[i])};
    if(!m){CHK_SPACE(aw[i])};
    if(!m){CHK_TAB(aw[i])};
    
    /* angles */
    if(!m){CHK_ANG(aw[i],nm,"ra",am,gc->ra);}
    if(!m){CHK_ANG(aw[i],nm,"dra",am,gc->dra);}
    if(!m){CHK_ANG(aw[i],nm,"ra1",am,gc->ra1);}
    if(!m){CHK_ANG(aw[i],nm,"dra1",am,gc->dra1);}
    if(!m){CHK_ANG(aw[i],nm,"dec",am,gc->dec);}
    if(!m){CHK_ANG(aw[i],nm,"ddec",am,gc->ddec);}
    if(!m){CHK_ANG(aw[i],nm,"dec1",am,gc->dec1);}
    if(!m){CHK_ANG(aw[i],nm,"ddec1",am,gc->ddec1);}
    if(!m){CHK_ANG(aw[i],nm,"px",am,gc->px);}
    if(!m){CHK_ANG(aw[i],nm,"pa",am,gc->pa);}
    if(!m){CHK_ANG(aw[i],nm,"glong",am,gc->glong);}
    if(!m){CHK_ANG(aw[i],nm,"glat",am,gc->glat);}
    if(!m){CHK_ANG(aw[i],nm,"tlat",am,gc->tlat);}
    if(!m){CHK_ANG(aw[i],nm,"tlong",am,gc->tlong);}
    if(!m){CHK_ANG(aw[i],nm,"alt",am,gc->alt);}
    if(!m){CHK_ANG(aw[i],nm,"az",am,gc->az);}
    if(!m){CHK_ANG(aw[i],nm,"ha",am,gc->ha);}
    if(!m){CHK_ANG(aw[i],nm,"elong",am,gc->elong);}
    if(!m){CHK_ANG(aw[i],nm,"elat",am,gc->elat);}
    if(!m){CHK_ANG(aw[i],nm,"sglong",am,gc->sglong);}
    if(!m){CHK_ANG(aw[i],nm,"sglat",am,gc->sglat);}
    if(!m){CHK_ANG(aw[i],nm,"el_lim",am,gc->el_lim);}


    /* time */
    if(!m){CHK_TIME(aw[i],nm,"lst",am,gc->lst);}
    if(!m){CHK_TIME(aw[i],nm,"lct",am,gc->lct);}
    if(!m){CHK_TIME(aw[i],nm,"utc",am,gc->utc);}
    if(!m){CHK_TIME(aw[i],nm,"ut1",am,gc->ut1);}
    if(!m){CHK_TIME(aw[i],nm,"tzone",am,gc->tzone);}
    if(!m){CHK_TIME(aw[i],nm,"gmst",am,gc->gmst);}
    if(!m){CHK_TIME(aw[i],nm,"gast",am,gc->gast);}
    if(!m){CHK_TIME(aw[i],nm,"dut",am,gc->dut);}
    if(!m){CHK_TIME(aw[i],nm,"rise",am,gc->rise);}
    if(!m){CHK_TIME(aw[i],nm,"set",am,gc->set);}
    
    /* double */
    if(!m){CHK_REAL(aw[i],nm,"mjd",am,gc->mjd);}
    if(!m){CHK_REAL(aw[i],nm,"epoch",am,gc->epoch);}
    if(!m){CHK_REAL(aw[i],nm,"epoch1",am,gc->epoch1);}
    if(!m){CHK_REAL(aw[i],nm,"equinox",am,gc->equinox);}
    if(!m){CHK_REAL(aw[i],nm,"equinox1",am,gc->equinox1);}
    if(!m){CHK_REAL(aw[i],nm,"rv",am,gc->rv);}
    if(!m){CHK_REAL(aw[i],nm,"rv1",am,gc->rv1);}
    if(!m){CHK_REAL(aw[i],nm,"freq",am,gc->freq);}
    if(!m){CHK_REAL(aw[i],nm,"freq1",am,gc->freq1);}

    /* integer */
    if(!m){CHK_INT(aw[i],nm,"gyear",am,gc->gyear);}
    if(!m){CHK_INT(aw[i],nm,"gmonth",am,gc->gmonth);}
    if(!m){CHK_INT(aw[i],nm,"gday",am,gc->gday);}
    if(!m){CHK_INT(aw[i],nm,"veldef",am,gc->veldef);}
    if(!m){CHK_INT(aw[i],nm,"velsys",am,gc->velsys);}
    if(!m){CHK_INT(aw[i],nm,"vel1sys",am,gc->vel1sys);}
    if(!m){CHK_INT(aw[i],nm,"freqsys",am,gc->freqsys);}
    if(!m){CHK_INT(aw[i],nm,"freq1sys",am,gc->freq1sys);}

    /* char */
    if(!m){CHK_CHAR(aw[i],nm,"eprefix",am,gc->eprefix);}
    if(!m){CHK_CHAR(aw[i],nm,"e1prefix",am,gc->e1prefix);}

    /* Default, print literal as string */
    if(!m){
      pt=PTP_STR;
      j=strlen(aw[i])+(nm>0 ? strlen(am):0)+1;
      if((s=malloc(j)) == NULL){
	tact_err(__FILE__,"Malloc Error\n",NULL);
	return 1;
      }
      strcpy(s,aw[i]);
      if(nm>0)strcat(s,am);
      m=1;
    }
    /* this should never arise */
    if(!m){NO_MATCH(aw[i]);} 

    switch(pt){
    case PTP_ANG:
      if(a2s(pD,sa,pst)){
	tact_err(__FILE__,"Error printing angle\n",NULL);
	return 1;
      }
      fprintf(fp,"%s ",sa);
      break;
    case PTP_TIME:
      if(a2s(pD,sa,pst)){
	tact_err(__FILE__,"Error printing time\n",NULL);
	return 1;
      }
      fprintf(fp,"%s ",sa);
      break;
    case PTP_NL:
      k= nm > 0 ? (int)atoi(am):1;
      for(l=0;l<k;l++)
	fprintf(fp,"\n");
      break;
    case PTP_SP:
      k= nm > 0 ? (int)atoi(am):1;
      for(l=0;l<k;l++)
	fprintf(fp," ");
      break;
    case PTP_TB:
      k= nm > 0 ? (int)atoi(am):1;
      for(l=0;l<k;l++)
	fprintf(fp,"\t");
      break;
    case PTP_STR:
      fprintf(fp,"%s",s);
      free(s);
      break;
    case PTP_REAL:
      fprintf(fp,fmt,pD);
      break;
    case PTP_INT:
      fprintf(fp,fmt,pI);
      break;
    case PTP_CHAR:
      fprintf(fp,fmt,pC);
      break;
    case PTP_HELP:
      fprintf(ga->hfp,
	      "**********          Tact Builtins        ************\n");
      strcpy(fmt,"%-");
      sprintf(fmt+2,"%2ds# %%s\n\0",MAX_NAME_LEN);
      for(l=0;l<ga->nc;l++)
	fprintf(ga->hfp,fmt,ga->tc[l].name,ga->tc[l].doc);
      fprintf(ga->hfp,
	      "********** Currently Defined Tact Macros ************\n");
      for(l=0;l<ga->nm;l++){
	fprintf(ga->hfp,fmt,ga->tm[l].name,ga->tm[l].doc);
	fprintf(ga->hfp,fmt,"",ga->tm[l].mc);
      }
      break;
    default:
      tact_err(__FILE__,"Illegal print type %i\n",pt,NULL);
      break;
    }
  }

  /* free allocated strings */
  if(na>0)
    for(i=0;i<na;free(aw[i]),i++);
  
  /* all done */
  return 0;
   
}

int getargm(char *a, char *am){
  char *p;
  int  i;

  if((p=strpbrk(a,"%"))==NULL)
    /* no modifier */
    return 0;

  /* terminate argument at modfier */
  *p='\0';
    
  /* copy modifer */
  for(i=0;*++p != '\0' && i < MAX_CMD_LEN -1;i++)
    am[i]=*p;

  /* terminate modifier */
  am[i]='\0';

  return 1;
}
