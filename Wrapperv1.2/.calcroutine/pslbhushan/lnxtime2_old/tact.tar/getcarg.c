
static char rcsid[]="$Id: getcarg.c,v 1.2 1998/01/16 07:10:02 chengalu Exp $";

/*
   function to return command arguments to tact
   Inputs:
   cb        command buffer
   bp        buffer pointer to starting location for read, updated
             on output to point to the character after that last
	     read. (If the last read character is the NULL char
	     the the pointer is left at the NULL char).

   Outputs:
   ca        command argument
   
   Return:
   0         successful
   1         error
         
   The command argument is returned as a NULL terminated string
   of characters. All leading space characters in the command buffer
   are ignored. The command argument terminates when the first space
   character is encountered, unless the command arguemnt is quoted 
   by the character constant QUOTE_CHAR. A QUOTE_CHAR toggles the
   the intepretation of space char as marking the end of the argument.
   The  QUOTE_CHAR itself can be escaped by preceding it with an ESC_CHAR. 
   The bounding QUOTE_CHARs of a quoted string are not included in the 
   output.
   
   Examples: (with QUOTE_CHAR as " and ESC_CHAR as \)
    Input                  Returns
    ------                 ---------
    goats                  goats
    "more goats"           more goats
    "still \" more goats"  still " more goats
    \"goats gallore\"      "goats
    \"goats" gallore\" "   "goats gallore" 
    \\""goats gallore\\""  \"goats gallore\"  


*/

#include <tact.h>
#include <ctype.h>

#define  QUOTE_CHAR   '\"'
#define  ESC_CHAR     '\\'

int   getcarg(char *cb, long *bp, char *ca)
{
    int i,j,quoted,isquote;

    quoted=0;
    isquote=0;
    for(j=0,i=*bp;cb[i] != '\0';i++){
	/* ignore leading space, but not empty arguments in quotes*/
	if(j==0 && !isquote)
	    if(isspace(cb[i]))
		continue;
	/* an ESC_CHAR escapes the quote */
	if(cb[i] == ESC_CHAR)
	    if(cb[i+1] == QUOTE_CHAR){
		/* ignore ESC_CHAR, copy the QUOTE_CHAR */
		ca[j++]= cb[++i];
		continue;
	    }
	/* non escaped quote begins or ends ignoring of blanks */
	if(cb[i] == QUOTE_CHAR){
	    quoted = 1-quoted;
	    isquote++;
		/* don't copy the quote character itself */
		continue;
	}
	/* non quoted space implies end of argument string */
	if(isspace(cb[i]) && !quoted){
	    /* empty argument not in quotes */
	    if(j==0 && !isquote){
		tact_err(__FILE__,"Missing Argument\n",NULL);
		return 1;
	    }
	    ca[j]='\0';
	    *bp = i+1;
	    return 0;
	}
	/* else copy into command argument */
	ca[j++]=cb[i];
	if(j==MAX_CMD_LEN-1){
	    /* abort if the command is too long */
	    ca[j-1]='\0';
	    tact_err(__FILE__,"Argument too long %s",ca,NULL);
	    return 1;
	}

    }
    /* Error if buffer end reached before end quotes */
    if(quoted){
	tact_err(__FILE__,"No Ending Quotes Found\n",NULL);
	return 1;
    }else{
	/* empty argument not in quotes */
	if(j==0 && !isquote){
	    tact_err(__FILE__,"Missing Argument\n",NULL);
	    return 1;
	}
	/* leave buffer pointer pointing to NULL character */
	ca[j]='\0';
	*bp  = i;
	return 0;
    }
}
#undef   QUOTE_CHAR
#undef   ESC_CHAR
