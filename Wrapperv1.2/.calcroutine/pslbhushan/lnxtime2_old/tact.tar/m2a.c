#include <tact.h>

static char rcsid[]="$Id: m2a.c,v 1.2 2000/12/08 09:52:43 chengalu Exp $";

int m2a(Gcord *gc, Garg *ga)
/*
  converts from mean to apparent position.
  Note: mjd has to be already set. If mjd is set from local civil time (lct)
        using the routine lct2utc() then the mjd is set in UTC, where as
        this routine strictly speaking requires TTD. However for most practical
        purposes UTC should suffice.

  input:
  ra
  dec
  dra
  ddec
  px
  rv
  epoch
  epoch1 (assumed set corresponding to mjd)
  mjd

  output:
  ra1
  dec1
  equinox1 (set to epoch1)
  e1prefix
*/

{
  if(gc->eprefix != 'J'){
    tact_err(__FILE__,"Mean->Apparent works only in FK5!(i.e. J)\n",NULL);
    return 1;
  }


  sla_map_(&gc->ra,&gc->dec,&gc->dra,&gc->ddec,&gc->px,&gc->rv,&gc->epoch,
	   &gc->mjd,&gc->ra1,&gc->dec1);

  
  gc->equinox1=gc->epoch1;
  gc->e1prefix=gc->eprefix;
  
  return 0;
}
