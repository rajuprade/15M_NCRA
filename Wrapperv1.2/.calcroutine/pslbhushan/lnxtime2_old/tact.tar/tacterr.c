#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <tact.h>

static char rcsid[]="$Id: tacterr.c,v 1.3 2002/10/31 10:05:56 chengalu Exp $";

int tact_err(char *s1,char *s2,...)
{
/*
  centralized error printing function.
  char  *s1    name of function generating error
  char  *s2    string to be printed
               if the first character of s2 is % then,s2 is assumed to be 
               a format specifier. If the first lower case letter in s2
               is
                'f' then a double argument is looked for and printed in
                    specified format
                'i' then a long argument is looked for and printed in the
                    specified format
		'c' then a character argument is looked for and printed in
                    the specified format
                's' then a string argument is looked for and printed in the
                    specified format.
               In all other cases s2 itself is printed out as a string.
               A NULL pointer marks the end of the argument list.
*/

  va_list ap;
  char    *cp1,*cp2;
  char    *s;
  long    l;
  double  d;
  char    c;
  extern  FILE *tefp;

  /* s1 assumed to be error msg generating func */
  if(s1 != NULL && strlen(s1))
    fprintf(tefp,"%s()",s1);

  /* nothing to print if format is empty */
  if(s2 == NULL || !strlen(s2))
    return 0;
  
  va_start(ap,s2);

  for(cp1=s2;cp1 != NULL && strlen(cp1);cp1=va_arg(ap,char *)){
      if((cp2=strpbrk(cp1,"%")) != NULL){
        /* format specifier present, check type of arg */
      for(;!(islower(*cp2) || *cp2 == '\0');cp2++);
      switch(*cp2){
      case 'c':
	/* print character - upgrade to int in gcc 2.96*/
	{ int k;
	  k=va_arg(ap,int);
	  c=k;
	  fprintf(tefp,cp1,c);
	}
	break;
      case 'f':
	/* print double */
	d=va_arg(ap,double);
	fprintf(tefp,cp1,d);
	break;
      case 'i':
	/* print long */
	l=va_arg(ap,long);
	fprintf(tefp,cp1,l);
	break;
      case 's':
	/* print string */
	s=va_arg(ap, char *);
	fprintf(tefp,cp1,s);
	break;
      default:
	/* default, print as string */
	fprintf(tefp,"%s",cp1);
	break;
      }
      break;
    }else{
      /* no format speficier, print as string */
      fprintf(tefp,"%s",cp1);
    }
  }

  va_end(ap);

  return 0;

}
#ifdef TEST_PROGRAM
int main(int argc, char **argv)
{

  tact_err(__FILE__,"test ProgName\n",NULL);
  tact_err(NULL,NULL);
  tact_err(NULL,"test NULL ProgName\n",NULL);
  tact_err(__FILE__,"test char %c\n",'3',NULL);
  tact_err(__FILE__,"test double %3.1f\n",3.0,NULL);
  tact_err(__FILE__,"test long %2i\n",3,NULL);
  tact_err(__FILE__,"test string %s\n","3.0",NULL);
  tact_err(__FILE__,"test undef %g\n",3.0,NULL);
  exit(0);
}
#endif
