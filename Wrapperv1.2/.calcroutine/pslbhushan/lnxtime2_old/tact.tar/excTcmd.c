#include <tact.h>

static char rcsid[]="$Id: excTcmd.c,v 1.1 1998/01/16 07:09:07 chengalu Exp $";

int excTcmd(char *cb, long *bp, Garg *ga, Gcord *gc,
		struct TactCmd *tcs, int *nc, struct TactMacro *tms, 
		int *nm)
{

  long mbp;
  int  r,i,m;
  char cm[MAX_CMD_LEN];
  
  while((r=getcmd(cb,bp,cm,ga->ca)) >= 0){
    /* blank command is normal end */
    if(!strlen(cm))
      return 0;
    /* macro defenition */
    if(r==1){
      for(m=0,i=0;i<*nm;i++){
	if(!strcmp(cm,tms[i].name)){
	  /* tact_err(__FILE__,"Warning: Macro %s redefined\n",cm); stop warning jnc 26/feb/07*/
	  strcpy(tms[i].mc,ga->ca);
	  m=1;
	  break;
	}
      }
      if(m==0){
	if(*nm < MAX_TACT_MACRO -1){
	  strcpy(tms[*nm].name,cm);
	  strcpy(tms[*nm].mc,ga->ca);
	  *nm=*nm+1;
	}else{
	  tact_err(__FILE__,"MAX_TACT_MACRO (%i) exceeded\n",MAX_TACT_MACRO,
		   NULL);
	  return 1;
	}
      }
    }else{
      /* see if this is a macro to execute */
      for(m=0,i=0;i<*nm;i++){
	if(!strcmp(cm,tms[i].name)){
	  mbp=0;
	  excTcmd(tms[i].mc,&mbp,ga,gc,tcs,nc,tms,nm);
	  m=1;
	  break;
	}
      }
      if(m!=1){
	/* see if this is an inbuilt command */
	for(m=0,i=0;i<*nc;i++){
	  if(!strcmp(cm,tcs[i].name)){
	    if((*tcs[i].gtf)(gc,ga)){
	      tact_err(__FILE__,"Error executing %s\n",cm,NULL);
	      return 1;
	    }
	    m=1;
	    break;
	  }
	}
	if(!m){
	  tact_err(__FILE__,"No Match for command %s\n",cm,NULL);
	  return 1;
	}
      }
    }
  }
  /* error from getcmd */
  return 1;
}
