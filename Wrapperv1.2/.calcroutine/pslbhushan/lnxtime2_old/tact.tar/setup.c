#include <tact.h>

#define  ChkCmSpc(x)  {if(++(x) == MAX_TACT_CMD)\
                        {tact_err(__FILE__,"Too Many Comands",NULL);return -1;}}

#define SetUpFunc(N,D,F) {  strcpy(tcs[nc].name,N);\
                            strcpy(tcs[nc].doc,D);\
                            tcs[nc].gtf=F;\
                            ChkCmSpc(nc);}


int setup(struct TactCmd tcs[])
{
  int nc=0;

  SetUpFunc("b2j","Converts from B1950.0 to J2000.0",b2j);

  SetUpFunc("j2b","Converts from J2000.0 to B1950.0",j2b);

  SetUpFunc("print","Generic printing function",tact_print);

  SetUpFunc("reset","Copy CrdSet1 to CrdSet0",resetcrd);
  
  return nc;

}
