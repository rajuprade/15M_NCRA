#include <tact.h>

static char rcsid[]="$Id: l2j.c,v 1.1 1998/01/16 07:14:13 chengalu Exp $";

int l2j(Gcord *gc, Garg *ga)
/*
  converts from galactic co-ordinates to J2000.0
  assumes that there is no proper motion in FK5 system

*/
{

  sla_galeq_(&gc->glong,&gc->glat,&gc->ra,&gc->dec);

  gc->eprefix='J';
  gc->equinox=2000.0;

  return 0;

}
