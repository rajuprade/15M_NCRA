/*
   function to return macro doccumentation to tact
   Inputs:
   Return:
   0         successful
   1         error
         
*/

#include <tact.h>

static char rcsid[]="$Id: getmdoc.c,v 1.1 1998/01/16 07:11:38 chengalu Exp $";

int   getmdoc(Gcord *gc, Garg *ga)
{
  char name[MAX_NAME_LEN];
  int i,j,k,m;
  
  /* get the macro name */
  for(i=0;i<MAX_NAME_LEN - 1 && ga->ca[i] != ',';i++)
    name[i]=ga->ca[i];
  if(ga->ca[i] != ','){
    tact_err(__FILE__,"Fatal:Missing Macro name in Doc\n",NULL);
    tact_err(NULL,"%s\n",ga->ca,NULL);
    return 1;
  }
  name[i]='\0';
  
  /* find which macro in the structure this is */
  for(m=0,k=0;k<ga->nm;k++){
    if(!strcmp(name,ga->tm[k].name)){
      /* copy the doccumentation line */
      for(i++,j=0;j< MAX_DOC_LEN -1 && ga->ca[i] != '\0';j++,i++)
	ga->tm[k].doc[j]=ga->ca[i];
      ga->tm[k].doc[j+1]='\0';
      m=1;
      break;
    }
  }
  if(!m){
    tact_err(__FILE__,"No such macro %s\n",name,NULL);
    return 1;
  }
      
  /* all done */
  return 0;

}
