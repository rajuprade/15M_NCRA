#include <tact.h>

int par_curve(Gcord *gc, Garg *ga)
/*
  compute paralactic angle as a function of lst or lct
  assumes that rise and set times is already computed
*/
{ char  lst[16],lct[16];

  if(gc->rise > gc->set) gc->rise -=2.0*PI;
  for(gc->lct=gc->rise;gc->lct<gc->set;gc->lct+=0.01)
  { lct2lst(gc,ga);
    lst2ha(gc,ga);
    altaz(gc,ga);
    a2s(gc->lst,lst,ATP_DH);
    a2s(gc->lct,lct,ATP_DH);
    if(gc->ha > M_PI) gc->ha -=2.0*M_PI;
    if(gc->dec > gc->tlat)
    { if(gc->ha<0.0)gc->pa+=M_PI;
      else gc->pa-=M_PI;
    }
    printf("IST= %s LST= %s HA= %f PAR_ANG= %f (deg)\n",lct,lst,gc->ha*180/M_PI,gc->pa*180/M_PI);
  }
  return 0;
}




