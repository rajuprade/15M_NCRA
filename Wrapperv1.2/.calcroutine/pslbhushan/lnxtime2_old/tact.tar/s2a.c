#include <tact.h>

static char rcsid[]="$Id: s2a.c,v 1.4 1998/06/26 09:09:51 chengalu Exp $";

#define STR_CPY(x,y,k)  {if((int)strlen(y) < k)\
                          strcpy(x,y);\
			 else{\
			  tact_err(__FILE__,"String Overflow\n",NULL);\
                          return 1;\
			 }}


int s2a(char *s, double *a)
/*
       function to convert from a string to an angle

       char   *s     input string
       double *a     output angle
                     (radians)
*/

{
  
  int tp=-1;
  int l0;

  if(s == NULL || !strlen(s)){
    /* error, empty input */
    fprintf(stderr,"s2a(): Empty input string\n");
    return 1;
  }

  l0=strlen(s);

  if(strstr(s,":") != NULL){
    /* colon separated angle */
    switch(s[l0-1]){
    case 'h':
      /* hours, minutes, seconds */
      tp=ATP_HMS;
      s[l0-1]='\0';
      break;
    case 'd':
      /* degrees, minutes, seconds */
      tp=ATP_DMS;
      s[l0-1]='\0';
      break;
    default:
      /* default degrees, minutes, seconds */
      tp=ATP_DMS;
      if(!isdigit(s[l0-1])){
	fprintf(stderr,"s2a(): Illegal qualifier %c\n",s[l0]);
	return 1;
      }
      break;
    }
  }else{
    /* decimal angle */
    switch(s[l0-1]){
    case 'h':
      /* decimal hours */
      tp=ATP_DH;
      s[l0-1]='\0';
      break;
    case 'd':
      /* decimal degrees */
      tp=ATP_DD;
      s[l0-1]='\0';
      break;
    case 'r':
      /* decimal radians */
      tp=ATP_DR;
      s[l0-1]='\0';
      break;
    default:
      /* default decimal degrees */
      tp=ATP_DD;
      if(!isdigit(s[l0-1])){
	fprintf(stderr,"s2a(): Illegal qualifier %c\n",s[l0]);
	return 1;
      }
      break;
    }
  }
  
  switch(tp){
  case ATP_HMS:
    /* hours, minutes, seconds */
    if(dms2a(s,a))
      return 1;
    *a = (*a)*15.0;
    break;
  case ATP_DMS:
    /* degrees, minutes, seconds */
    if(dms2a(s,a))
      return 1;
    break;
  case ATP_DH:
    /* decimal hours */
    *a=atof(s)*15.0;
    break;
  case ATP_DD:
    /* decimal degrees */
    *a=atof(s);
    break;
  case ATP_DR:
    /* decimal radians */
    *a=atof(s);
    *a=RAD2DEG(*a);
    break;
  default:
    fprintf(stderr,"s2a(): Illegal angle type %d\n",tp);
    return 1;
  }
  /* convert to radians */
  *a=DEG2RAD(*a);

  return 0;
}
      
int dms2a(char *s, double *a)
/*
  function to read colon separated angle specification
  and convert into a floating point number
  char   *s   input string
  double *a   output number
              (decimal degrees)
*/
{
  
  char *p;
  char w[3][MAX_FIELD_LEN];
  int  i;

  /* clear all fields */
  for(i=0;i<3;i++)
    strcpy(w[i]," ");
    
  /* get first field */
  if((p=strtok(s,":"))==NULL){
    fprintf(stderr,"dms2a(): Missing colon separators\n");
    return 1;
  }
  STR_CPY(w[0],p,MAX_FIELD_LEN);
    
  /* get remaining fields */
  for(i=1;(p=strtok(NULL,":"));i++){
    if(i<3){
      STR_CPY(w[i],p,MAX_FIELD_LEN);
    }else{
      fprintf(stderr,"dms2a(): Too many colon separated fields\n");
      return 1;
    }
  }

  /* convert into decimal degrees */
  if(atof(w[0]) < 0.0 || w[0][0]=='-'){
    *a= -atof(w[0])+atof(w[1])/(double)60.0 +atof(w[2])/(double)3600.0;
    *a= -(*a);
  }else{
    *a= atof(w[0])+atof(w[1])/(double)60.0 +atof(w[2])/(double)3600.0;
  }

  return 0;
}

#ifdef TEST_PROGRAM
int main(int argc, char **argv)
{
  char s[1024];
  double a;

  for(printf("Input String:");gets(s);printf("Input String:")){
    s2a(s,&a);
    printf("Converted to %f\n",a);
  }
  return 0;
}
#endif
