#include <tact.h>

static char rcsid[]="$Id: shwTstruct.c,v 1.2 2002/10/31 10:07:32 chengalu Exp $";

int shwTstruct(Gcord *gc, Garg *ga)
/*
  prints out the entire tact sturcture
*/     
{
  int i=0;
  FILE *fp;

  char *t[]={
  "double ra;                        /* right ascention (radians)   */",
  "double dec;                       /* declination (radians)       */",
  "double dra;                       /* proper motion in ra         */",
  "double ddec;                      /* proper motion in dec        */",
  "double epoch;                     /* epoch of (ra,dec)           */",
  "char   eprefix;                   /* epoch prefix ('B' or 'J')   */",
  "double equinox;                   /* equinox of (ra,dec)         */",
  "double ra1;                       /* right ascention (radians)   */",
  "double dec1;                      /* declination (radians)       */",
  "double dra1;                      /* proper motion in ra1        */",
  "double ddec1;                     /* proper motion in dec1       */",
  "double px;                        /* parallax (radians)          */",
  "double rv;                        /* radial velocity (km/s)      */",
  "double epoch1;                    /* epoch of (ra1,dec1)         */",
  "char   e1prefix;                  /* epoch prefix ('B' or 'J')   */",
  "double equinox1;                  /* equinox of (ra1,dec1)       */",
  "double mjd;                       /* modified julian date        */",
  "double gyear;                     /* greogrian year              */",
  "double gmonth;                    /* gregorian month             */",
  "double gday;                      /* gregorian day               */",
  "double lct;                       /* local civil time (radians)  */",
  "double utc;                       /* (radians)                   */",
  "double dut;                       /* utc+dut=ut1  (radians)      */",
  "double lst;                       /* LAST               (radians)*/",
  "double ut1;                       /* ut1 (radians)               */",
  "double gmst;                      /* (radians)                   */",
  "double gast;                      /* (radians)                   */",
  "double tzone;                     /* lct+tzone = utc (radians)   */",
  "double glong;                     /* galactic longitude (radians)*/",
  "double glat;                      /* galactic latitude (radians) */",
  "double elong;                     /* ecliptic longitude (radians)*/",
  "double elat;                      /* ecliptic latitude (radians) */",
  "double sglong;                    /* supergal longitude (radians)*/",
  "double sglat;                     /* supergal latitude (radians) */",
  "double alt;                       /* altitude (radians)          */",
  "double az;                        /* azimuth (radians)           */",
  "double ha;                        /* hour angle (radians)        */",
  "double pa;                        /* parallactic angle (radians) */",
  "double tlat;                      /* terrestrial lat (radians)   */",
  "double tlong;                     /* terestrial lon (radians)    */",
  "double rise;                      /* rise time       (radians)   */",
  "double set;                       /* set time        (radians)   */",
  "double el_lim;                    /* elevation limit (radians)   */",
  "" /* Don't Forget an Empty String! */
  };

  fp=ga->ofp;

  for(i=0;strlen(t[i]);i++)
    fprintf(fp,"%s\n",t[i]);

  return 0;
}
