#include <tact.h>

static char rcsid[]="$Id: prcmdline.c,v 1.5 2001/08/10 06:15:26 chengalu Exp $";

#define SET_EPB    " set:eprefix,B,epoch,1950.0,equinox,1950.0 "
#define SET_EPJ    " set:eprefix,J,epoch,2000.0,equinox,2000.0 "

#define STR_CAT(x,y)  {if((int)(strlen(x) + strlen(y)) < MAX_BUFF_LEN)\
                        strcat(x,y);\
               	       else{\
		        tact_err(__FILE__,"Command buffer Overflow\n",NULL);\
                        return 1;\
                       }}

#define SET_PAR(o,p,k) {if( (int)(k) < argc){\
                         STR_CAT(cb," set:");\
                         STR_CAT(cb,p);\
			 STR_CAT(cb,",");\
		         STR_CAT(cb,argv[k]);\
		       }else{\
                         tact_err(__FILE__,"-%s Missing argument\n",o,NULL);\
                         return 1;\
                       }}

#define ADD_CMDS(s1,s2,s3,s4) {if(!strcmp(s1,s2)){\
	                      STR_CAT(cb," ");\
                              STR_CAT(cb,s3);\
                              STR_CAT(cb,s4);\
	                      break;\
		           }}

int prcmdline(int argc, char **argv, char *cb, Garg *ga, Gcord *gc)
{

  int  i,c,j,m,nlp=0;
  char *cp;
  int  dd,yy,mm;
  int  DiM[12]={31,28,31,30,31,30,31,31,30,31,30,31};
  double fy;
  void usage(FILE *fp);

  for(i=1;i<argc;i++){
    switch((c=strlen(argv[i]))){
    case 2:
      if(argv[i][0] != '-'){
	tact_err(__FILE__,"Illegal option %s\n",argv[i]);
	return 1;
      }
      switch(argv[i][1]){
      case 'a':
	/* set azimuth */
	SET_PAR("a","az",i+1);
	i++;
	break;
      case 'b':
	/* set galactic latitude */
	SET_PAR("b","glat",i+1);
	i++;
	break;
      case 'B':
	/* print out the command buffer and exit */
	while(*cb){
	  fprintf(ga->hfp,"%c",*cb);
	  cb++;
	}
	exit(0);
      case 'd':
	/* set dec */
	SET_PAR("d","dec",i+1);
	i++;
	break;
      case 'D':
	/* set date and also epoch1, equinox1, e1prefix */
	m=0;
	if(i+1 < argc){
	  if((cp=strtok(argv[i+1],"/")) !=NULL){
	    dd=(int)atoi(cp);
	    if((cp=strtok(NULL,"/")) !=NULL){
	      mm=(int)atoi(cp);
	      if((cp=strtok(NULL,"/")) !=NULL){
		yy=(int)atoi(cp);
		m++;
	      }
	    }
	  }
	  /* set second (epoch,equinonx) to date */
	  if(0 < mm && mm <= 12){
	    if(dd <= DiM[mm-1]){
	      for(fy=0.0,j=0;j<mm-1;j++)
		fy +=DiM[j];
	      fy += dd;
	      fy = fy/365.25;
	      fy = yy +fy;
	      STR_CAT(cb," set:e1prefix,J");
	      STR_CAT(cb," set:epoch1,");
	      sprintf(cb+strlen(cb),"%f",fy);
	      STR_CAT(cb," set:equinox1,");
	      sprintf(cb+strlen(cb),"%f",fy);
	      m++;
	    }
	  }
	  if(m!=2){
	    tact_err(__FILE__,"Bad date\n",NULL);
	    return 1;
	  }
	  /* set date */
	  STR_CAT(cb," set:gday,");
	  sprintf(cb+strlen(cb),"%i",dd);
	  STR_CAT(cb," set:gmonth,");
	  sprintf(cb+strlen(cb),"%i",mm);
	  STR_CAT(cb," set:gyear,");
	  sprintf(cb+strlen(cb),"%i",yy);
	}else{
	  tact_err(__FILE__,"-d Missing argument\n",NULL);
	  return 1;
	}
	i++;
	break;
      case 'e':
	/* set epoch, equinox, eprefix */
	if(i+1 < argc){
	  STR_CAT(cb," set:eprefix,");
	  if(isalpha(argv[i+1][0])){
	    switch(argv[i+1][0]){
	    case 'B':
	      STR_CAT(cb,"B");
	      break;
	    case 'J':
	      STR_CAT(cb,"J");
	      break;
	    default:
	      tact_err(__FILE__,"Illegal epoch %c\n",argv[i+1][0],NULL);
	      return 1;
	    }
	    cp= &argv[i+1][1];
	  }else{
	    if(fabs(atof(argv[i+1])-1950.0) > TACT_TINY){
	      STR_CAT(cb,"J");
	    }else{
	      STR_CAT(cb,"B");
	    }
	    cp= argv[i+1];
	  }
	  STR_CAT(cb," set:equinox,");
	  STR_CAT(cb,cp);
	  STR_CAT(cb," set:epoch,");
	  STR_CAT(cb,cp);
	}else{
	  tact_err(__FILE__,"-e Missing argument\n",NULL);
	  return 1;
	}
	i++;
	break;
      case 'E':
	/* set epoch1, equinox1, e1prefix */
	if(i+1 < argc){
	  STR_CAT(cb," set:e1prefix,");
	  if(isalpha(argv[i+1][0])){
	    switch(argv[i+1][0]){
	    case 'B':
	      STR_CAT(cb,"B");
	      break;
	    case 'J':
	      STR_CAT(cb,"J");
	      break;
	    default:
	      tact_err(__FILE__,"Illegal epoch %c\n",argv[i+1][0],NULL);
	      return 1;
	    }
	    cp= &argv[i+1][1];
	  }else{
	    if(fabs(atof(argv[i+1])-1950.0) > TACT_TINY){
	      STR_CAT(cb,"J");
	    }else{
	      STR_CAT(cb,"B");
	    }
	    cp= argv[i+1];
	  }
	  STR_CAT(cb," set:equinox1,");
	  STR_CAT(cb,cp);
	  STR_CAT(cb," set:epoch1,");
	  STR_CAT(cb,cp);
	}else{
	  tact_err(__FILE__,"-E Missing argument\n",NULL);
	  return 1;
	}
	i++;
	break;
      case 'F':
	/* freq1 */
	SET_PAR("F","freq1",i+1);
	i++;
	break;
      case 'f':
	/* set freq */
	SET_PAR("f","freq",i+1);
	i++;
	break;
      case 'h':
	/* set hour angle */
	SET_PAR("h","ha",i+1);
	i++;
	break;
      case 'H':
	/* show all inbuilts an macros, stop processing switches */
	STR_CAT(cb," print:help");
	return 0;
      case 'l':
	/* set galactic longitude */
	SET_PAR("l","glong",i+1);
	i++;
	break;
      case 'P':
	/* show all the elements of the gc struct, stop processing switches */
	STR_CAT(cb," shw");
	return 0;
      case 'r':
	/* set right ascention */
	SET_PAR("r","ra",i+1);
	if(isdigit(argv[i+1][strlen(argv[i+1])-1]))
	  STR_CAT(cb,"h");
	i++;
	break;
      case 'S':
	/* show all the command line switches */
	usage(ga->efp);
	exit(0);
      case 't':
	/* set the local time */
	SET_PAR("t","lct",i+1);
	if(isdigit(argv[i+1][strlen(argv[i+1])-1]))
	   STR_CAT(cb,"h");
	i++;
	break;
      case 'V':
	/* print version and exit */
	tact_err("tact","version: %s\n",TACT_VERSION);
	exit(0);
      case 'v':
	/* set the velocity (km/s) */
	SET_PAR("v","rv",i+1);
	i++;
	break;
      case 'z':
	/* set the altitude */
	SET_PAR("z","alt",i+1);
	i++;
	break;
      default:
	tact_err(__FILE__,"Illegal option %s\n",argv[i]);
	return 1;
      }
      break;
    default:
      /* check for various commonly used transformations */
      ADD_CMDS(argv[i],"a2b","","a2b pcs1");
      ADD_CMDS(argv[i],"b2a",SET_EPB,"b2a pcs1");
      ADD_CMDS(argv[i],"a2j","","a2j pcs1");
      ADD_CMDS(argv[i],"a2l","","a2l pgc");
      ADD_CMDS(argv[i],"b2j",SET_EPB,"b2j pcs1");
      ADD_CMDS(argv[i],"b2l",SET_EPB,"b2l pgc");
      ADD_CMDS(argv[i],"j2a",SET_EPJ,"j2a pcs1");
      ADD_CMDS(argv[i],"j2b",SET_EPJ,"j2b pcs1");
      ADD_CMDS(argv[i],"j2l",SET_EPJ,"j2l pgc");
      ADD_CMDS(argv[i],"l2a","","l2a pcs1");
      ADD_CMDS(argv[i],"l2b","","l2b pcs1");
      ADD_CMDS(argv[i],"l2j","","l2j pcs");
      /* if no match, just copy command */
      STR_CAT(cb," ");
      STR_CAT(cb,argv[i]);
      break;
    }
  }
  
  /* give a space at the end of the buffer */
  STR_CAT(cb," ");
  return 0;
}
#undef STR_CAT
#undef SET_PAR

void usage(FILE *fp)
{
  fprintf(fp,
	  "USAGE:tact [-a (az)][-b (glat)][-B (shbuff)[-d (dec)][-D (date)]");
  fprintf(fp,"[-e (epoch)]\n");
  fprintf(fp,
	  "           [-E (epoch1)][-h (ha)][-H (help)][-l (glon)]");
  fprintf(fp,"[-P (showpar)][-r (ra)]\n");
  fprintf(fp,
	  "           [-S (switches)][-t (local time)][-z (alt)]");
  fprintf(fp,"[-v (Vhel km/s)]\n");
  fprintf(fp,
	  "           [-V (version)][-F (fsky MHz)][-f (frest MHz)]\n");
  fprintf(fp,
	  "           [a2b (arbit to B1950)][a2j (arbit to J2000)]");
  fprintf(fp,"[a2l (arbit to gal)]\n");
  fprintf(fp,
	  "           [b2j (B1950 to J2000)][b2l (B1950 to gal)]");
  fprintf(fp,"[j2a (J2000 to arbit)]\n");
  fprintf(fp,
	  "           [j2b (J2000 to B1950)][j2l (J2000 to gal)]");
  fprintf(fp,"[l2a (gal to arbit)]\n");
  fprintf(fp,
	  "           [l2b (gal to B1950)][l2j (gal to J2000)]");
  fprintf(fp,"[b2a (arbit to B1950)]\n");
  fprintf(fp,
	  "           [f2v (fsky2vhel)][v2f (vhel2fsky)]\n");
  fprintf(fp,
	  "                    *See the man page for more help*\n");

}






