#include <tact.h>

static char rcsid[]="$Id: ec2eq.c,v 1.1 1998/01/16 07:07:35 chengalu Exp $";

int ec2eq(Gcord *gc, Garg *ga)
/*
  converts from ecliptic to equitoral (J2000) co-ordinates

  input:
  elong
  elat 
  mjd    (Note: should be TDB, instead is UTC)
  
  output:
  ra1
  dec1
  epoch1
  equinox1
  e1prefix
*/

{

  sla_ecleq_(&gc->elong,&gc->elat,&gc->mjd,&gc->ra1,&gc->dec1);

  gc->epoch1=2000.0;
  gc->equinox1=2000.0;
  gc->e1prefix='J';
  
  return 0;
}
