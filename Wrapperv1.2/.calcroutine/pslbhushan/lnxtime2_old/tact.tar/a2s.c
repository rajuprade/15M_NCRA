#include <tact.h>

/*  
   Function to convert an angle from radians into segagesimal notation.

   int    ty  output angle type, 
              (see tact.h)
   char   s   char string 
              (length at least 15)
   double a   input angle 
              (radians)

*/

int a2s(double a, char *st, int ty)
{
  double s,a1;
  int    h,m;
  char   sgn,sh[3],sm[3],ss[7];

  /* convert to decimal degrees */
  a=RAD2DEG(a);

  switch(ty){
  case ATP_HMS:
    /* output hr min sec */
    while(a < 0.0)
      a += 360.0;
    a1 = (a - 360.0*(int)floor(a/360.0))/15.0;                  
    break;
  case ATP_DMS:
    /* output deg min sec */
    while(fabs(a) > 180.0)
      a -= (fabs(a)/a)*360.0;
    a1 = fabs(a);                      
    break;
  case ATP_DH:
    /* output in decimal hours */
    while(a < 0.0)
      a += 360.0;
    while(a > 360.0)
      a -= 360.0;
    a = (a - 360.0*(int)floor(a/360.0))/15.0;                  
    break;
  case ATP_DD:
    /* output decimal degrees */
    while(fabs(a) > 180.0)
      a -= (fabs(a)/a)*360.0;
    break;
  case ATP_DR:
    /* output in decimal radians */
    a=DEG2RAD(a);
    while(fabs(a) > PI)
      a -=(fabs(a)/a)*(2.0*PI);
    break;
  case ATP_DLO:
    /* output in decimal degrees, range (0,360)*/
    while(a < 0.0)
      a += 360.0;
    while(a > 360.0)
      a -= 360.0;
    a = (a - 360.0*(int)floor(a/360.0));
    break;
  default:
    fprintf(stderr,"a2s(): Illegal angle type %d\n",ty);
    return 1;
  }
  
  if(ty == ATP_HMS || ty == ATP_DMS){
    h  = (int)floor(a1);
    sprintf(sh,(h < 10 )? "0%1d":"%2d",h);
  
    a1 = (a1 -h)*60.0;
    m  = (int)floor(a1);
    sprintf(sm,(m < 10 )? "0%1d":"%2d",m);
  
    s = (a1 - m)*60.0;
    sprintf(ss,(s < 10.0)? "0%5.3f":"%6.3f",s);
  }

  switch(ty){
  case ATP_HMS:
    sprintf(st,"%2s:%2s:%6s",sh,sm,ss);
    break;
  case ATP_DMS:
    sgn = a < 0.0 ? '-' : '+';
    sprintf(st,"%1c%2s:%2s:%6s",sgn,sh,sm,ss);
    break;
  case ATP_DH:
    sprintf(st,"%11.7f",a);
    break;
  case ATP_DD:
    sprintf(st,"%11.7f",a);
    break;
  case ATP_DR:
    sprintf(st,"%11.7f",a);
    break;
  case ATP_DLO:
    sprintf(st,"%11.6f",a);
    break;
  default:
    fprintf(stderr,"a2s(): Illegal angle type %d\n",ty);
    return 1;
  }

  return 0;

}

#ifdef TEST_PROGRAM
int main(int argc, char **argv)
{
  double a;
  int    ty;
  char   s[15];
  char   line[1024];

  for(printf("Typ Ang:");gets(line);printf("Typ Ang:")){
   sscanf(line,"%d %lf",&ty,&a);
   fprintf(stderr,"%s: %d %lf\n",line,ty,a);
   a2s(a,s,ty);
   printf("%s\n",s);
  }
  return 0;
}
#endif

