/*
   function to return macro defenition to tact
   Inputs:
   cb        command buffer
   bp        buffer pointer to starting location for read, updated
             on output to point to the character after that last
	     read. (If the last read character is the NULL char
	     the the pointer is left at the NULL char).

   Outputs:
   ca        macro defenition
   
   Return:
   0         successful
   1         error
         
   The command argument is returned as a NULL terminated string
   of characters. All leading space characters in the command buffer
   are ignored. The command argument terminates when the first unescaped
   semi-colon character encountered. The escape character is a backslash.

*/

#include <tact.h>
#include <ctype.h>

static char rcsid[]="$Id: getmdef.c,v 1.1 1998/01/16 07:11:11 chengalu Exp $";

int   getmdef(char *cb, long *bp, char *ca)
{

  int i,j;
  
  for(j=0,i=*bp;cb[i] != '\0';i++){
    /* ignore leading space */
    if(j==0 && isspace(cb[i]))
      continue;
    if(cb[i] == ';' && cb[i-1] != '\\'){
      ca[j]='\0';
      *bp=i+1;
      return 0;
    }
    if(j < MAX_MACRO_LEN -1){
      ca[j++]=cb[i];
    }else{
      ca[j]='\0';
      tact_err(__FILE__,"%s exceeds ",ca,NULL);
      tact_err(NULL,"MAX_MACRO_LEN (%i)\n",MAX_MACRO_LEN,NULL);
      return 1;
    }
  }
  
  /* reached end of command buffer */
  if(j < MAX_MACRO_LEN -1){
    ca[j++]=cb[i];
    *bp=i;
  }else{
    ca[j]='\0';
    tact_err(__FILE__,"%s exceeds",ca," MAX_MACRO_LEN (%i)",
	     MAX_MACRO_LEN,NULL);
    return 1;
  }
  return 0;
}
