#include <tact.h>

static char rcsid[]="$Id: eq2ec.c,v 1.1 1998/01/16 07:08:05 chengalu Exp $";

int eq2ec(Gcord *gc, Garg *ga)
/*
  converts from equitoral(J2000) to ecliptic co-ordinates

  input:
  ra
  dec
  mjd    (Note: should be TDB, instead is UTC)
  
  output:
  ra1
  dec1
  epoch1
  equinox1
  e1prefix
*/

{

  if(fabs(gc->equinox-2000.0) >TACT_TINY || gc->eprefix !='J'){
    tact_err(__FILE__,"Input Co-ordinates not J2000\n",NULL);
    return 1;
  }

  sla_eqecl_(&gc->ra,&gc->dec,&gc->mjd,&gc->elong,&gc->elat);

  return 0;
}
