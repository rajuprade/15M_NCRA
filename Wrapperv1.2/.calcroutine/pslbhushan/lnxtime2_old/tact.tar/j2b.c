#include <tact.h>

static char rcsid[]="$Id: j2b.c,v 1.2 1998/01/16 07:13:27 chengalu Exp $";

int j2b(Gcord *gc, Garg *ga)
/*
  converts from J2000.0 to B1950.0
  assumes that there is no proper motion in the FK5 system
  forces the output epoch to B1950.0

  input:
   ra
   dec
   epoch
  output:
   ra1
   dra1
   dec1
   ddec1
   e1prefix ('B')
   equinox1 (1950.0)
   epoch1   (1950.0)

*/
{

  if(gc->eprefix != 'J' || fabs(gc->equinox -(double)2000.0)>TACT_TINY){
    tact_err(__FILE__,"Input co-ordinates not J2000\n",NULL);
    return 1;
  }

  /* set the output epoch, equinox */
  gc->epoch1=1950.0;
  gc->e1prefix='B';
  gc->equinox1=1950.0;

  sla_fk54z_(&gc->ra,&gc->dec,&gc->epoch1,&gc->ra1,&gc->dec1,&gc->dra1,
	     &gc->ddec1);

  return 0;

}
