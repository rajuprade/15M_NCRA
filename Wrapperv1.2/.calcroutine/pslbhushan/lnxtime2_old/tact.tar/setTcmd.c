#include <tact.h>

static char rcsid[]="$Id: setTcmd.c,v 1.4 2003/06/30 10:50:21 chengalu Exp $";

#define  ChkCmSpc(x)  {if(++(x) == MAX_TACT_CMD)\
                        {tact_err(__FILE__,"Too Many Comands",NULL);return -1;}}

#define SetUpFunc(N,D,F) {  strcpy(tcs[nc].name,N);\
                            strcpy(tcs[nc].doc,D);\
                            tcs[nc].gtf=F;\
                            ChkCmSpc(nc);}


int setTcmd(struct TactCmd tcs[])
{
  int nc=0;

  SetUpFunc("altaz",
	    "Converts (ha,ra,dec) to (alt,az,pa) [sla_altaz]",altaz);
  SetUpFunc("b2j",
	    "Converts from B1950.0 to J2000.0 [sla_fk45z]",b2j);
  SetUpFunc("e2h",
	    "Converts from (ra,dec) to (alt,az) [sla_e2h]",e2h);
  SetUpFunc("ec2eq",
	    "Converts from ecliptic (date) to equitorial (J2000) [sla_eqecl]",
	    ec2eq);
  SetUpFunc("eq2ec",
	    "Converts from equitorial (J2000) to ecliptic (date) [sla_ecleq]",
	    eq2ec);
  SetUpFunc("fobs2fhel",
	    "Convert from Fobs to Fhel",fobs2fhel);
  SetUpFunc("fobs2vhel",
	    "Convert from Fobs to Vhel",fobs2vhel);
  SetUpFunc("fhel2fobs",
	    "Convert from Fhel to Fobs",fhel2fobs);
  SetUpFunc("gal2sup",
	    "Converts from galactic to super-galactic [sla_galsup]",gal2sup);
  SetUpFunc("h2e",
	    "Converts from (alt,az,lst) to (ha,ra,dec) [sla_h2e]",h2e);
  SetUpFunc("ha2lst",
	    "Converts from (ra,ha) to (lst)",ha2lst);
  SetUpFunc("j2b",
	    "Converts from J2000.0 to B1950.0 [sla_fk54z]",j2b);
  SetUpFunc("j2l",
	    "Converts from J2000.0 to Galactic [sla_eqgal]",j2l);
  SetUpFunc("l2j",
	    "Converts from Galactic to J2000.0 [sla_galeq]",l2j);
  SetUpFunc("lct2lst",
	    "Converts local civil time to local siderial time [sla_gmst]",
	    lct2lst);
  SetUpFunc("lct2utc",
	    "Converts local civil time to universal co-ord time",
	    lct2utc);
  SetUpFunc("lst2ha",
	    "Converts LST to HA using appraent RA",lst2ha);
  SetUpFunc("m2a",
	    "Converts from mean to apparaent (FK5 only) [sla_map]",m2a);
  SetUpFunc("mdoc",
	    "Stores macro doccumentation",getmdoc);
  SetUpFunc("par_curve",
	    "Computes paralactic angle curve [sla_altaz]",par_curve);
  SetUpFunc("prec",
	    "Preceses co-ordinates [sla_preces]",prec);
  SetUpFunc("print",
	    "Generic printing function",tact_print);
  SetUpFunc("reset",
	    "Copy CrdSet1 to CrdSet0",resetcrd);
  SetUpFunc("resetep",
	    "Copy EpEqSet1 to EpEqSet0",resetep);
  SetUpFunc("rise_set",
	    "Computes the rise and set time",rise_set);
  SetUpFunc("set",
	    "Set various input prameters",setTstruct);
  SetUpFunc("shw",
	    "Show all the setable prameters",shwTstruct);
  SetUpFunc("solcol",
	    "Compute Solar Coordinates",solcol);
  SetUpFunc("sup2gal",
	    "Converts from super-galactic to galactic [sla_supgal]",sup2gal);
  SetUpFunc("vhel2fobs",
	    "Convert from Vhel to Fobs",vhel2fobs);
  SetUpFunc("vhel2vlsr",
	    "Convert from Vhel to Vlsr",vhel2vlsr);
  SetUpFunc("vlsr2vhel",
	    "Convert from Vlsr to Vhel",vlsr2vhel);

  return nc;

}
