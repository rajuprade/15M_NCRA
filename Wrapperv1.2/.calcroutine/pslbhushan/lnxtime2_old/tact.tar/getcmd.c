#include <tact.h>
#include <ctype.h>

static char rcsid[]="$Id: getcmd.c,v 1.2 1998/01/16 07:10:50 chengalu Exp $";

int getcmd(char *cb, long *bp, char *cm, char *ca)
{
/*
    function to read the next command and command argument from
    the command buffer.
    char *cb    command buffer
    long *bp    current position in the command buffer (updated)
    char *cm    command to (returned)
    char *ca    command argument (returned)

    returns 
     0         normal command
     1         macro defenition
    -1         error

*/

  int   i,j;

  /* set the argument to null */
  strcpy(ca,"");

  /* get the command itself */
  for(i=*bp,j=0;cb[i]!='\0';i++){
    /* skip leading space */
    if(j==0 && isspace(cb[i]))
      continue;
    /* end of command, set pointer to next char */
    if(isspace(cb[i])){
      *bp = i+1;
      cm[j]='\0';
      return 0;
    }
    /* command argument or macro defenition present, get it*/
    if(cb[i] == ':'){
      *bp = i+1;
      cm[j] = '\0';
      /* get the macro defenition */
      if(cb[i+1] == '='){
	i++;
	*bp = i+1;
	if(getmdef(cb, bp, ca)){
	  tact_err(__FILE__,"Cannot process Argument to %s",
		   cm,NULL);
	  return -1;
	}
	return 1;
      }else{
	/* get the command argument */
	if(getcarg(cb, bp, ca)){
	  tact_err(__FILE__,"Cannot process Argument to %s",
		   cm,NULL);
	  return -1;
	}
	return 0;
      }
    }
    /* copy char from buffer */
    cm[j++]=cb[i];
    if(j==MAX_CMD_LEN-1){
      /* abort if the command is too long */
      cm[j-1]='\0';
      tact_err(__FILE__,"Command too long %s\n",cm,NULL);
      return -1;
    }
  }
  /* reached end of buffer, leave pointer at NULL char */
  cm[j]='\0';
  *bp=i;
  return 0;
}

	   
	    
