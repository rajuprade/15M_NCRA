#include <tact.h>

static char rcsid[]="$Id: b2j.c,v 1.3 2000/12/08 09:55:31 chengalu Exp $";

int b2j(Gcord *gc, Garg *ga)
/*
  converts from B1950.0 to J2000.0
  assumes that there is no proper motion in the FK5 system
  forces epoch to 2000.0 
  input:
   ra
   dec
   epoch
  output:
   ra1
   dec1
   e1prefix ('J')
   equinox1 (2000.0)
   epoch (2000.0)

*/

{
  if(gc->eprefix != 'B' || fabs(gc->equinox -(double)1950.0)>TACT_TINY){
    tact_err(__FILE__,"Input co-ordinates not B1950\n",NULL);
    return 1;
  }

  sla_fk45z_(&gc->ra,&gc->dec,&gc->epoch,&gc->ra1,&gc->dec1);
  
  /* set the output epoch,equinox */
  gc->e1prefix='J';
  gc->equinox1=2000.0;
  gc->epoch1=2000.0;
  return 0;

}
