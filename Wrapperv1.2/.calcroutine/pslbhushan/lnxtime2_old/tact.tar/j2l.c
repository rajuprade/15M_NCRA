#include <tact.h>

static char rcsid[]="$Id: j2l.c,v 1.1 1998/01/16 07:13:46 chengalu Exp $";

int j2l(Gcord *gc, Garg *ga)
/*
  converts from J2000.0 to galactic co-ordinates.
  assumes:
   (1)Input Co-ords are J2000.0
   (2)that there is no proper motion in the FK5 system.

   input:
   ra
   dec
   output:
   glong
   glat

*/
{

  if(gc->eprefix != 'J' || fabs(gc->equinox -(double)2000.0)>TACT_TINY){
    tact_err(__FILE__,"Input co-ordinates not J2000\n",NULL);
    return 1;
  }

  sla_eqgal_(&gc->ra,&gc->dec,&gc->glong,&gc->glat);

  return 0;

}
