#include <tact.h>

static char rcsid[]="$Id: resetcrd.c,v 1.2 1998/01/16 07:17:29 chengalu Exp $";

int resetcrd(Gcord *gc, Garg *ga)
{
/*
  copies co-ordiante set 1 into co-ordianate set 0

*/
  char *ca;
  int   i,na;
  char  *aw[MAX_ARG],am[MAX_CMD_LEN],arg[MAX_CMD_LEN];
  
  
  ca=ga->ca;

  /* decompose the command argument */
  if((na=prarg(ca, aw))==-1){
    tact_err(__FILE__,"Bad Arg %s\n",ca,NULL);
    return 1;
  }
  if(na==0)strcpy(arg,"c");
  else strncpy(arg,aw[0],MAX_CMD_LEN-1);
  
  for(i=0;i<strlen(arg);i++)
  { switch(arg[i])
    { case 'c':
	gc->ra      = gc->ra1;
	gc->dec     = gc->dec1;
	gc->epoch   = gc->epoch1;
	gc->eprefix = gc->e1prefix;
	gc->equinox = gc->equinox1;
	gc->dra     = gc->dra1;
	gc->ddec    = gc->ddec1;
	break;
      case 'v':
	gc->rv      = gc->rv1;
	gc->velsys  = gc->vel1sys;
	break;
      case 'f':
	gc->freq    = gc->freq1;
	gc->freqsys = gc->freq1sys;
	break;
      default:
	tact_err(__FILE__,"Bad Arg %s Expect NULL or c,v,f\n",arg);
	return 1;
    }
  }
     
     return 0;
 
}


